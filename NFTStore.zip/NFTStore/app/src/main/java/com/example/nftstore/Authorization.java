package com.example.nftstore;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Authorization extends AppCompatActivity {

    ImageButton enter_button, sign_up_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.authorization);

        enter_button = findViewById(R.id.enter_button);
        sign_up_button = findViewById(R.id.sign_up_button);

        sign_up_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRegistrationWindow();
            }
        });
    }

    private void openRegistrationWindow() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Sign up now");
        dialog.setMessage("Enter all the registration details");

        LayoutInflater inflater = LayoutInflater.from(this);
        View registration_window = inflater.inflate(R.layout.registration_window, null);
        dialog.setView(registration_window);
    }
}